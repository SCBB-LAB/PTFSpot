import os, sys
from Bio.PDB import PDBParser
from Bio.SeqUtils import seq1
d3to1 = {'CYS': 'C', 'ASP': 'D', 'SER': 'S', 'GLN': 'Q', 'LYS': 'K',
 'ILE': 'I', 'PRO': 'P', 'THR': 'T', 'PHE': 'F', 'ASN': 'N', 
 'GLY': 'G', 'HIS': 'H', 'LEU': 'L', 'ARG': 'R', 'TRP': 'W', 
 'ALA': 'A', 'VAL':'V', 'GLU': 'E', 'TYR': 'Y', 'MET': 'M', 'N': 'M'}

method = str(str(sys.argv[2])+"/pdb/"+str(sys.argv[3])+".pdb")


pdbparser = PDBParser()
record = method
parser = PDBParser(QUIET=True)
structure = parser.get_structure('struct', record)    

for model in structure:
	for chain in model:
		seq = []
		for residue in chain:
			if residue.resname in d3to1.keys():
				seq.append(d3to1[residue.resname])
			else:
				seq.append(d3to1["N"])
		print(str('>tf\n')+str(''.join(seq)))

