import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
from keras.regularizers import l2, l1
import sys, numpy as np, tensorflow as tf, tensorflow, keras, numpy, pandas as pd, warnings, re, math, numpy, pickle
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from keras import layers
from pickle import load
from keras.preprocessing.text import Tokenizer
from tensorflow.keras.utils import pad_sequences
from tensorflow.keras.layers import Input, Dense, Flatten, Dropout
from multiprocessing import Pool
from utils import TransformerBlock, TokenAndPositionEmbedding, comparison, create_tokenizer, max_length, encode_text, max_length, encode_text, replacementstr

def s2(k):
	a=[]
	text5=[seq[k][i:i+5] for i in range(len(seq[k])-(4))]
	text7=[seq[k][i:i+7] for i in range(len(seq[k])-6)]
	text2=[seq[k][i:i+2] for i in range(len(seq[k])-1)]
	texts62=' '.join(text7)
	texts72=' '.join(text5) 
	texts22=' '.join(text2) 
	a.append(str(texts22)+" "+str(texts62)+" "+str(texts72))
	f2 = encode_text(tokenizer, a, length)
	return f2

length=470
import itertools
bases=['A','T','G','C']
m=[]
for p,j in itertools.product(bases, repeat=2):
	m.append(p+j)

o=' '.join(m)
m=[]
for p,j,a,b,c in itertools.product(bases, repeat=5):
	m.append(p+j+a+b+c)

m=' '.join(m)
n=[]
for p,j,a,b,c,d,e in itertools.product(bases, repeat=7):
	n.append(p+j+a+b+c+d+e)

n=' '.join(n)
a=[str(o)+' '+str(m)+' '+str(n)]
tokenizer=create_tokenizer(a)
vocab_size = len(tokenizer.word_index) + 1

embed_dim = 28
num_heads = 14
ff_dim = 14

filename=str(sys.argv[1])
folder=str(sys.argv[3]+"/")
tff=str(sys.argv[2])

infile=[x.strip() for x in open(folder+filename+"_data.fa").readlines()]
fastadict={}
for line in infile:
    if not line:
        continue
    if line.startswith('>'):
        sname = line
        if line not in fastadict:
            fastadict[line] = ''
        continue
    fastadict[sname] += line

ids=list(fastadict.keys())
seq = list(fastadict.values())
name = Pool().map(s2, [sent for sent in range(len(seq))])
X_testy = numpy.array(name)
X_testy = X_testy.reshape(X_testy.shape[0], X_testy.shape[2])

inputs = layers.Input(shape=(length,))
embedding_layer = TokenAndPositionEmbedding(length, vocab_size, embed_dim)
x = embedding_layer(inputs)
transformer_block = TransformerBlock(embed_dim, num_heads,ff_dim)
x = transformer_block(x)
x = layers.GlobalAveragePooling1D()(x)
x = layers.Dropout(0.25)(x)
x = layers.Dense(38, activation="relu")(x)
x = layers.Dense(12, activation="selu", name='my_dense')(x)
x = layers.Dropout(0.25)(x)
outputs = layers.Dense(1, activation="sigmoid")(x)
model = keras.Model(inputs=inputs, outputs=outputs)
model.compile(loss='binary_crossentropy',optimizer="adam",metrics=['accuracy'])
model.load_weights('model/'+tff+'.h5')
y_pred = model.predict(X_testy)

infile=[x.strip() for x in open(folder+filename).readlines()]
fastadict={}
for line in infile:
    if not line:
        continue
    if line.startswith('>'):
        sname = line
        if line not in fastadict:
            fastadict[line] = ''
        continue
    fastadict[sname] += line

f3 = open(folder+tff+"_predict",'w')
for i,j in enumerate(y_pred):
	zz=replacementstr(ids[i])
	f3.writelines(zz[0]+"\t"+str(zz[1]+75)+"\t"+str(zz[2]-75)+"\t"+str(j[0])+"\t"+fastadict[">"+zz[0]][zz[1]+75:zz[2]-75]+"\n")

f3.close()


