import os, sys, numpy as np
from tensorflow.keras.utils import pad_sequences

def change3(jac):
	if len(jac)==3:
		return jac
	elif len(jac)==4:
		return jac[1:]


def foo(string):
	string = string.replace(" ", "")
	return string


def ch4(zz):
	main = []
	main.append(foo("".join(zz[0:4])))
	main.append(foo("".join(zz[6:11])))
	main.append(foo("".join(zz[12:16])))
	main.append(foo("".join(zz[17:20])))
	main.append(foo("".join(zz[21:22])))
	main.append(foo("".join(zz[22:26])))
	main.append(foo("".join(zz[30:38])))
	main.append(foo("".join(zz[38:46])))
	main.append(foo("".join(zz[46:54])))
	main.append(foo("".join(zz[54:60])))
	main.append(foo("".join(zz[60:66])))
	main.append(foo("".join(zz[76:78])))
	return main


def change4(l, data):
	xx = float(l[0])
	yy = float(l[1])
	zz = float(l[2])
	if xx >=0  and yy >=0 and zz >=0:
		xx = float(xx/data['xmx'])
		yy = float(yy/data['ymx'])
		zz = float(zz/data['zmx'])
		ll = [xx, yy, zz]
		return ll
	elif xx >=0  and yy >=0 and zz < 0:
		xx = float(xx/data['xmx'])
		yy = float(yy/data['ymx'])
		zz = float(zz/data['zmn'])
		ll = [xx, yy, zz]
		return ll
	elif xx >=0  and yy < 0 and zz >=0:
		xx = float(xx/data['xmx'])
		yy = float(yy/data['ymn'])
		zz = float(zz/data['zmx'])
		ll = [xx, yy, zz]
		return ll
	elif xx >=0  and yy < 0 and zz < 0:
		xx = float(xx/data['xmx'])
		yy = float(yy/data['ymn'])
		zz = float(zz/data['zmn'])
		ll = [xx, yy, zz]
		return ll
	elif xx < 0  and yy >=0 and zz >=0:
		xx = float(xx/data['xmn'])
		yy = float(yy/data['ymx'])
		zz = float(zz/data['zmx'])
		ll = [xx, yy, zz]
		return ll
	elif xx < 0  and yy >=0 and zz < 0:
		xx = float(xx/data['xmn'])
		yy = float(yy/data['ymx'])
		zz = float(zz/data['zmn'])
		ll = [xx, yy, zz]
		return ll
	elif xx < 0  and yy < 0 and zz >=0:
		xx = float(xx/data['xmn'])
		yy = float(yy/data['ymn'])
		zz = float(zz/data['zmx'])
		ll = [xx, yy, zz]
		return ll
	elif xx < 0  and yy < 0 and zz < 0:
		xx = float(xx/data['xmn'])
		yy = float(yy/data['ymn'])
		zz = float(zz/data['zmn'])
		ll = [xx, yy, zz]
		return ll

def result(sysy, sss):
	f1= [ch4(i) for i in open(sss+sysy+".pdb").readlines()]
	f2=[]
	for list in f1:
		id = list[0]
		if id == 'ATOM':
			f2.append(list)
	f3=[]
	alph = 0
	for alp, jac in enumerate(f2):
		if alph < len(f2):
			jac = f2[alph]
			if len(jac[3])==3:		
				f3.append(jac)
				alph = alph+1
			else:
				f4=[]
				for az, sz in enumerate(f2[alph:]):
					if sz[3][0]=='A':
						f4.append(sz)
						alph = alph+1
					elif sz[3][0]=='B':
						f4.append(sz)
						alph = alph+1
						if not alph >= len(f2) and f2[alph][3][0]=='C':
							f4.append(f2[alph])
							alph = alph+1
							break
						else:
							break
				occu = float(f4[0][9])
				f6=[]
				for i in f4:
					if occu > float(i[9]):
						pass
					elif occu < float(i[9]):
						f6.append(i)
				if len(f6)==0:
					f3.append(f4[0])
				else:
					f3.append(f6[0])
	adict={}
	bdict={}
	for alp, jac in enumerate(f3):
		jac[3]=change3(jac[3])
		adict[jac[5]]=np.zeros((24,3))
		bdict[jac[5]]=0
	for alp, jac in enumerate(f3):
		bdict[jac[5]]+=1
	x=[]
	y=[]
	z=[]
	for alp, jac in enumerate(f3):
		x.append(float(jac[6]))
		y.append(float(jac[7]))
		z.append(float(jac[8]))
	data={'xmx': max(x), 'xmn': abs(min(x)), 'ymx': max(y), 'ymn': abs(min(y)), 'zmx': max(z), 'zmn': abs(min(z))}
	alph = 0
	for alp, jac in enumerate(f3):
		if not alph == len(f3):
			jac = f3[alph]
			for i in range(0, bdict[jac[5]]):
				if alph <= len(f3) and not i>=24:
					out = change4(f3[alph+i][6:9], data)
					adict[jac[5]][i] = np.array(out, dtype='float32')
			alph = alph+bdict[jac[5]]
	clist=[]
	for i in adict:
		clist.append(adict[i])
	abf = np.array(clist)
	abf = abf.reshape(1, abf.shape[0], abf.shape[1], abf.shape[2])
	abf = pad_sequences(abf, maxlen=300, padding='post', dtype='float32')
	abf = abf.reshape(abf.shape[1], abf.shape[2], abf.shape[3])
	return abf
