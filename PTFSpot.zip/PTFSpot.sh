python3 $4/pdb/4.py $1 $2 $3 >$2/check.fa
printf "$1\t$2\t$3\n" >$2/check.txt
python3 $4/deeptfactor/tf_running.py -i $2/check.fa -o $4/deeptfactor/result -g cpu --checkpoint  $4/deeptfactor/trained_model/DeepTFactor_ckpt.pt
aa=`sed '1d' $4/deeptfactor/result/prediction_result.txt |head -1|awk '{if($3>=0.5) {print "1"} else {print "0"}}'`
saa=`sed 's+.pdb++' $2/check.txt|awk '{print $3}'`
printf "$1\t$2\t$3\n$aa\n$saa\n" >>$2/check.txt
if [ $aa -eq 1 ]
then  
   $4/M2 $1 $2 $saa
else
   echo "Provided pdb file is not of Transcription factor"
fi




