import os, sys
def replacementint(a):
	b=[]
	for i in a:
		b.append(int(i))
	return b

filename=str(sys.argv[1])
folder=str(sys.argv[2]+"/")
length=int(sys.argv[3])
motif_position=folder+filename+"_for"
header=[]
cord=[]
f1=open(motif_position, 'r')
for i in f1:
	z=i.split()
	zz=z[0].replace(">", "")
	header.append(zz)
	s=z[1].replace("[", "")
	s=s.replace(",]", "")
	s=s.split(",")
	cord.append(replacementint(s))

f1.close()
f3=open(folder+filename+"_data.bed",'w')
for i, j in enumerate(cord):
	for k in j:
		f3.writelines(header[i]+"\t"+str(k-75)+"\t"+str(k+length+75)+"\n")

f3.close()
os.system("awk '{if($2>0) print $0}' "+folder+filename+"_data.bed >"+folder+filename+"_data.bed_temp")
os.system("mv "+folder+filename+"_data.bed_temp "+folder+filename+"_data.bed")
os.system("bedtools getfasta -fi "+folder+filename+" -bed "+folder+filename+"_data.bed -fo "+folder+filename+"_data.fa")
